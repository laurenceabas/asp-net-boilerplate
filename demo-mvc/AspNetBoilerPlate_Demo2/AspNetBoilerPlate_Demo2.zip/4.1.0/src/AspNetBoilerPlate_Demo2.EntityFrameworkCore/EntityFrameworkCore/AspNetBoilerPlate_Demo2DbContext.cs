﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AspNetBoilerPlate_Demo2.EntityFrameworkCore
{
    public class AspNetBoilerPlate_Demo2DbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public AspNetBoilerPlate_Demo2DbContext(DbContextOptions<AspNetBoilerPlate_Demo2DbContext> options) 
            : base(options)
        {

        }
    }
}
