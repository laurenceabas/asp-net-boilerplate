namespace AspNetBoilerPlate_Demo2.Web.Controllers
{
    public class LayoutController : AspNetBoilerPlate_Demo2ControllerBase
    {

    }
}