﻿namespace AspNetBoilerPlate_Demo2
{
    public class AspNetBoilerPlate_Demo2Consts
    {
        public const string LocalizationSourceName = "AspNetBoilerPlate_Demo2";

        public const string ConnectionStringName = "Default";
    }
}